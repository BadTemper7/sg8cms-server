# ============================================================
# RestrictPC.ps1 - SG8 Launcher + PC lockdown listener
#
# Responsibilities:
# - Reads C:\ProgramData\SG8Launcher\identity.json
# - Uses API/WS values from identity.json only
# - Opens SG8 Launcher immediately on script start as offline fallback
# - Also opens SG8 Launcher when backend sends isLaunchedGame=true
# - Ignores isLaunchedGame=false because Electron closes itself
# - Locks/unlocks Windows controls from TERMINAL_LOCK_UPDATE only
# - Does not wait for websocket before opening SG8 Launcher on PC startup
# - Does not update isLaunchedGame itself. Electron updates it after opening.
# - No REST polling fallback. If websocket is not connected, no lock action is applied.
#
# Lockdown blocks:
# - Right click
# - Windows keys
# - Apps/Menu key
# - Alt+Tab
# - Alt+Esc
# - Alt+F4
# - Alt+Space
# - Ctrl+Esc
# - Ctrl+Shift+Esc
# - Ctrl+Alt+Q removes the RestrictPC startup task and exits
# - Windows Search window and taskbar search
# - Task Manager policy
# - Explorer context menus policy
# - Windows hotkeys policy
# ============================================================

param(
    [switch]$DebugMode
)

$script:DebugMode = $DebugMode.IsPresent
$script:IsLocked = $false
$script:PolicyApplied = $false
$script:LogFilePath = $null

$createdNew = $false
$script:singleInstanceMutex = [System.Threading.Mutex]::new(
    $true,
    "Global\SG8LauncherRestrictPC",
    [ref]$createdNew
)

if (-not $createdNew) {
    exit 0
}

function Log {
    param([string]$Message, [string]$Level = "INFO")

    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [$Level] $Message"

    if ($script:DebugMode) {
        Write-Host $line
    }

    if (-not [string]::IsNullOrWhiteSpace($script:LogFilePath)) {
        try {
            Add-Content -Path $script:LogFilePath -Value $line -Encoding UTF8
        } catch {}
    }
}

function Hide-ConsoleWindow {
    if ($script:DebugMode) { return }

    Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("User32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
'

    try {
        $consolePtr = [Console.Window]::GetConsoleWindow()
        if ($consolePtr -ne [IntPtr]::Zero) {
            [Console.Window]::ShowWindow($consolePtr, 0) | Out-Null
        }
    } catch {}
}

function Get-ProgramDataRoot {
    if ([string]::IsNullOrWhiteSpace($env:ProgramData)) {
        return "C:\ProgramData"
    }

    return $env:ProgramData
}

function Read-JsonFile {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        throw "JSON file not found: $Path"
    }

    $raw = (Get-Content -Path $Path -Raw).Trim()
    if ([string]::IsNullOrWhiteSpace($raw)) {
        throw "JSON file is empty: $Path"
    }

    return $raw | ConvertFrom-Json
}

function Normalize-ApiBaseUrl {
    param([string]$Value)

    $raw = [string]$Value
    $raw = $raw.Trim().TrimEnd('/')

    if ([string]::IsNullOrWhiteSpace($raw)) {
        return ""
    }

    $raw = $raw -replace '/api$', ''
    return $raw
}

function Normalize-WsUrl {
    param(
        [string]$Value,
        [string]$ApiBaseUrl
    )

    $raw = [string]$Value
    $raw = $raw.Trim().TrimEnd('/')

    if ([string]::IsNullOrWhiteSpace($raw)) {
        $api = Normalize-ApiBaseUrl -Value $ApiBaseUrl
        if ([string]::IsNullOrWhiteSpace($api)) {
            return ""
        }
        $raw = $api
    }

    if ($raw -match '^https://') { return ($raw -replace '^https://', 'wss://') }
    if ($raw -match '^http://') { return ($raw -replace '^http://', 'ws://') }
    if ($raw -match '^wss?://') { return $raw }

    return "ws://$raw"
}

function Get-BooleanValue {
    param($Value)

    if ($Value -eq $true) { return $true }
    if ($Value -eq $false) { return $false }

    $text = ([string]$Value).Trim().ToLower()

    if ($text -eq "true") { return $true }
    if ($text -eq "false") { return $false }

    return $null
}

function Get-MessageIsLaunchedGame {
    param($Message)

    $values = @(
        $Message.data.isLaunchedGame,
        $Message.payload.isLaunchedGame,
        $Message.isLaunchedGame,
        $Message.terminal.isLaunchedGame
    )

    foreach ($value in $values) {
        $parsed = Get-BooleanValue -Value $value
        if ($parsed -ne $null) {
            return $parsed
        }
    }

    return $null
}

function Get-MessageIsLocked {
    param($Message)

    $values = @(
        $Message.data.isLocked,
        $Message.payload.isLocked,
        $Message.isLocked,
        $Message.terminal.isLocked
    )

    foreach ($value in $values) {
        $parsed = Get-BooleanValue -Value $value
        if ($parsed -ne $null) {
            return $parsed
        }
    }

    return $null
}

function Get-MessageTerminalId {
    param($Message)

    $values = @(
        $Message.data.terminalId,
        $Message.data._id,
        $Message.payload.terminalId,
        $Message.payload._id,
        $Message.terminalId,
        $Message.terminal._id
    )

    foreach ($value in $values) {
        $text = ([string]$value).Trim()
        if (-not [string]::IsNullOrWhiteSpace($text)) {
            return $text
        }
    }

    return ""
}

function Get-MessageMachineId {
    param($Message)

    $values = @(
        $Message.data.machineId,
        $Message.data.deviceKey,
        $Message.payload.machineId,
        $Message.payload.deviceKey,
        $Message.machineId,
        $Message.deviceKey,
        $Message.terminal.machineId,
        $Message.terminal.deviceKey
    )

    foreach ($value in $values) {
        $text = ([string]$value).Trim()
        if (-not [string]::IsNullOrWhiteSpace($text)) {
            return $text
        }
    }

    return ""
}

function Is-MessageForThisTerminal {
    param(
        $Message,
        [string]$TerminalId,
        [string]$MachineId
    )

    $messageTerminalId = Get-MessageTerminalId -Message $Message
    $messageMachineId = Get-MessageMachineId -Message $Message

    if (-not [string]::IsNullOrWhiteSpace($messageTerminalId)) {
        return $messageTerminalId -eq $TerminalId
    }

    if (-not [string]::IsNullOrWhiteSpace($messageMachineId)) {
        return $messageMachineId -eq $MachineId
    }

    # Some websocket servers already scope the connection by device and do not
    # include terminalId or machineId in each payload.
    return $true
}

function Add-QueryParam {
    param(
        [string]$ExistingQuery,
        [string]$Name,
        [string]$Value
    )

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $ExistingQuery
    }

    if (-not [string]::IsNullOrWhiteSpace($ExistingQuery)) {
        $ExistingQuery += "&"
    }

    $ExistingQuery += "$Name=$([System.Uri]::EscapeDataString($Value))"
    return $ExistingQuery
}

function Build-WebSocketUri {
    param(
        [string]$WsUrl,
        [string]$TerminalId,
        [string]$MachineId,
        [string]$OutletName
    )

    $builder = New-Object System.UriBuilder -ArgumentList $WsUrl
    $query = $builder.Query

    if ($query.StartsWith('?')) {
        $query = $query.Substring(1)
    }

    # Register this listener under the terminal id first.
    # Older backend wsServer versions use deviceCode OR deviceMongoId as the
    # websocket map key. Using terminal id for both makes backend launch
    # broadcasts reliably reach RestrictPC even when Electron is closed.
    # Do not send outletName here. Outlet name can register the listener under
    # the outlet instead of the terminal.
    $query = Add-QueryParam -ExistingQuery $query -Name "deviceCode" -Value $TerminalId
    $query = Add-QueryParam -ExistingQuery $query -Name "deviceMongoId" -Value $TerminalId
    $query = Add-QueryParam -ExistingQuery $query -Name "terminalId" -Value $TerminalId
    $query = Add-QueryParam -ExistingQuery $query -Name "deviceKey" -Value $MachineId
    $query = Add-QueryParam -ExistingQuery $query -Name "machineId" -Value $MachineId
    $query = Add-QueryParam -ExistingQuery $query -Name "client" -Value "restrictpc"

    $builder.Query = $query
    return $builder.Uri
}

function Test-LauncherRunning {
    param([string]$LauncherPath)

    $processName = [System.IO.Path]::GetFileNameWithoutExtension($LauncherPath)
    $running = Get-Process -Name $processName -ErrorAction SilentlyContinue

    return $null -ne $running
}

function Open-Launcher {
    param([string]$LauncherPath)

    if (-not (Test-Path $LauncherPath)) {
        Log "Launcher executable not found: $LauncherPath" "ERROR"
        return
    }

    if (Test-LauncherRunning -LauncherPath $LauncherPath) {
        Log "Launcher is already running. Open request ignored."
        return
    }

    try {
        Start-Process -FilePath $LauncherPath | Out-Null
        Log "Launcher opened: $LauncherPath"
    } catch {
        Log "Failed to open launcher: $_" "ERROR"
    }
}

function Ensure-LockdownHookType {
    if ("SG8.LockdownHooks" -as [type]) {
        return
    }

    Add-Type -ReferencedAssemblies "System.Windows.Forms" -TypeDefinition @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace SG8 {
    public static class LockdownHooks {
        private const int WH_KEYBOARD_LL = 13;
        private const int WH_MOUSE_LL = 14;
        private const int WM_QUIT = 0x0012;

        private const int WM_KEYDOWN = 0x0100;
        private const int WM_SYSKEYDOWN = 0x0104;

        private const int WM_RBUTTONDOWN = 0x0204;
        private const int WM_RBUTTONUP = 0x0205;
        private const int WM_RBUTTONDBLCLK = 0x0206;
        private const int WM_NCRBUTTONDOWN = 0x00A4;
        private const int WM_NCRBUTTONUP = 0x00A5;
        private const int WM_NCRBUTTONDBLCLK = 0x00A6;
        private const int WM_CONTEXTMENU = 0x007B;

        private const int VK_TAB = 0x09;
        private const int VK_ESCAPE = 0x1B;
        private const int VK_SPACE = 0x20;
        private const int VK_LWIN = 0x5B;
        private const int VK_RWIN = 0x5C;
        private const int VK_APPS = 0x5D;
        private const int VK_S = 0x53;
        private const int VK_Q = 0x51;
        private const int VK_F4 = 0x73;
        private const int VK_CONTROL = 0x11;
        private const int VK_SHIFT = 0x10;

        private const int LLKHF_ALTDOWN = 0x20;

        private static IntPtr keyboardHook = IntPtr.Zero;
        private static IntPtr mouseHook = IntPtr.Zero;
        private static HookProc keyboardProc = KeyboardCallback;
        private static HookProc mouseProc = MouseCallback;
        private static Thread hookThread;
        private static uint hookThreadId = 0;
        private static bool running = false;
        public static volatile bool ExitRequested = false;

        private delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential)]
        private struct KBDLLHOOKSTRUCT {
            public int vkCode;
            public int scanCode;
            public int flags;
            public int time;
            public IntPtr dwExtraInfo;
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll")]
        private static extern uint GetCurrentThreadId();

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool PostThreadMessage(uint idThread, int Msg, UIntPtr wParam, IntPtr lParam);

        public static void Start() {
            if (running) return;
            ExitRequested = false;
            running = true;

            hookThread = new Thread(RunHookThread);
            hookThread.IsBackground = true;
            hookThread.SetApartmentState(ApartmentState.STA);
            hookThread.Start();
        }

        public static void Stop() {
            running = false;
            try {
                if (hookThreadId != 0) {
                    PostThreadMessage(hookThreadId, WM_QUIT, UIntPtr.Zero, IntPtr.Zero);
                }
            } catch {}
        }

        private static void RunHookThread() {
            hookThreadId = GetCurrentThreadId();

            IntPtr moduleHandle = IntPtr.Zero;
            try {
                using (Process currentProcess = Process.GetCurrentProcess())
                using (ProcessModule currentModule = currentProcess.MainModule) {
                    moduleHandle = GetModuleHandle(currentModule.ModuleName);
                }
            } catch {}

            keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, keyboardProc, moduleHandle, 0);
            mouseHook = SetWindowsHookEx(WH_MOUSE_LL, mouseProc, moduleHandle, 0);

            Application.Run();

            if (keyboardHook != IntPtr.Zero) {
                UnhookWindowsHookEx(keyboardHook);
                keyboardHook = IntPtr.Zero;
            }

            if (mouseHook != IntPtr.Zero) {
                UnhookWindowsHookEx(mouseHook);
                mouseHook = IntPtr.Zero;
            }

            hookThreadId = 0;
        }

        private static bool IsDown(int vk) {
            return (GetAsyncKeyState(vk) & 0x8000) != 0;
        }

        private static bool ShouldBlockKey(int vkCode, int flags) {
            bool altDown = (flags & LLKHF_ALTDOWN) == LLKHF_ALTDOWN || IsDown(0x12);
            bool winDown = IsDown(VK_LWIN) || IsDown(VK_RWIN);
            bool ctrlDown = IsDown(VK_CONTROL);
            bool shiftDown = IsDown(VK_SHIFT);

            if (ctrlDown && altDown && vkCode == VK_Q) { ExitRequested = true; return true; }
            if (vkCode == VK_LWIN || vkCode == VK_RWIN || vkCode == VK_APPS) return true;
            if (winDown && vkCode == VK_S) return true;
            if (winDown && vkCode == VK_Q) return true;
            if (altDown && vkCode == VK_TAB) return true;
            if (altDown && vkCode == VK_ESCAPE) return true;
            if (altDown && vkCode == VK_F4) return true;
            if (altDown && vkCode == VK_SPACE) return true;
            if (ctrlDown && vkCode == VK_ESCAPE) return true;
            if (ctrlDown && shiftDown && vkCode == VK_ESCAPE) return true;

            return false;
        }

        private static IntPtr KeyboardCallback(int nCode, IntPtr wParam, IntPtr lParam) {
            if (nCode >= 0) {
                int msg = wParam.ToInt32();
                if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) {
                    KBDLLHOOKSTRUCT info = (KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(KBDLLHOOKSTRUCT));
                    if (ShouldBlockKey(info.vkCode, info.flags)) {
                        return (IntPtr)1;
                    }
                }
            }

            return CallNextHookEx(keyboardHook, nCode, wParam, lParam);
        }

        private static IntPtr MouseCallback(int nCode, IntPtr wParam, IntPtr lParam) {
            if (nCode >= 0) {
                int msg = wParam.ToInt32();
                if (
                    msg == WM_RBUTTONDOWN ||
                    msg == WM_RBUTTONUP ||
                    msg == WM_RBUTTONDBLCLK ||
                    msg == WM_NCRBUTTONDOWN ||
                    msg == WM_NCRBUTTONUP ||
                    msg == WM_NCRBUTTONDBLCLK ||
                    msg == WM_CONTEXTMENU
                ) {
                    return (IntPtr)1;
                }
            }

            return CallNextHookEx(mouseHook, nCode, wParam, lParam);
        }
    }
}
'@
}

function Set-RegistryDword {
    param(
        [string]$Path,
        [string]$Name,
        [int]$Value
    )

    try {
        if (-not (Test-Path $Path)) {
            New-Item -Path $Path -Force | Out-Null
        }

        New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType DWord -Force | Out-Null
    } catch {
        Log "Failed to set registry $Path $Name=$Value : $_" "WARN"
    }
}

function Remove-RegistryValue {
    param(
        [string]$Path,
        [string]$Name
    )

    try {
        if (Test-Path $Path) {
            Remove-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue
        }
    } catch {
        Log "Failed to remove registry $Path $Name : $_" "WARN"
    }
}

function Apply-LockdownPolicies {
    $explorerPolicies = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    )

    foreach ($path in $explorerPolicies) {
        Set-RegistryDword -Path $path -Name "NoViewContextMenu" -Value 1
        Set-RegistryDword -Path $path -Name "NoTrayContextMenu" -Value 1
        Set-RegistryDword -Path $path -Name "NoWinKeys" -Value 1
        Set-RegistryDword -Path $path -Name "NoFind" -Value 1
        Set-RegistryDword -Path $path -Name "NoClose" -Value 1
    }

    $searchExplorerPolicies = @(
        "HKCU:\Software\Policies\Microsoft\Windows\Explorer",
        "HKLM:\Software\Policies\Microsoft\Windows\Explorer"
    )

    foreach ($path in $searchExplorerPolicies) {
        Set-RegistryDword -Path $path -Name "DisableSearchBoxSuggestions" -Value 1
    }

    Set-RegistryDword -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "SearchboxTaskbarMode" -Value 0

    $systemPolicies = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System"
    )

    foreach ($path in $systemPolicies) {
        Set-RegistryDword -Path $path -Name "DisableTaskMgr" -Value 1
    }

    $script:PolicyApplied = $true
}

function Remove-LockdownPolicies {
    $explorerPolicies = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    )

    foreach ($path in $explorerPolicies) {
        Remove-RegistryValue -Path $path -Name "NoViewContextMenu"
        Remove-RegistryValue -Path $path -Name "NoTrayContextMenu"
        Remove-RegistryValue -Path $path -Name "NoWinKeys"
        Remove-RegistryValue -Path $path -Name "NoFind"
        Remove-RegistryValue -Path $path -Name "NoClose"
    }

    $searchExplorerPolicies = @(
        "HKCU:\Software\Policies\Microsoft\Windows\Explorer",
        "HKLM:\Software\Policies\Microsoft\Windows\Explorer"
    )

    foreach ($path in $searchExplorerPolicies) {
        Remove-RegistryValue -Path $path -Name "DisableSearchBoxSuggestions"
    }

    Remove-RegistryValue -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "SearchboxTaskbarMode"

    $systemPolicies = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System"
    )

    foreach ($path in $systemPolicies) {
        Remove-RegistryValue -Path $path -Name "DisableTaskMgr"
    }

    $script:PolicyApplied = $false
}

function Stop-RestrictedProcesses {
    $names = @(
        "Taskmgr",
        "ProcessHacker",
        "procexp",
        "procexp64",
        "cmd",
        "powershell",
        "WindowsTerminal",
        "SearchHost",
        "SearchApp",
        "SearchUI",
        "SearchProtocolHost"
    )

    foreach ($name in $names) {
        try {
            Get-Process -Name $name -ErrorAction SilentlyContinue | ForEach-Object {
                if ($_.Id -ne $PID) {
                    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
                }
            }
        } catch {}
    }
}

function Enable-Lockdown {
    if ($script:IsLocked) {
        Stop-RestrictedProcesses
        return
    }

    Log "Enabling PC lockdown"
    $script:IsLocked = $true

    try {
        Ensure-LockdownHookType
        [SG8.LockdownHooks]::Start()
        Log "Keyboard and mouse hooks started"
    } catch {
        Log "Failed to start keyboard/mouse hooks: $_" "ERROR"
    }

    Apply-LockdownPolicies
    Stop-RestrictedProcesses
    Log "PC lockdown enabled. Right click, Windows shortcuts, and Windows Search should now be blocked."
}

function Disable-Lockdown {
    if (-not $script:IsLocked -and -not $script:PolicyApplied) {
        return
    }

    Log "Disabling PC lockdown"
    $script:IsLocked = $false

    try {
        if ("SG8.LockdownHooks" -as [type]) {
            [SG8.LockdownHooks]::Stop()
        }
    } catch {
        Log "Failed to stop keyboard/mouse hooks: $_" "WARN"
    }

    Remove-LockdownPolicies
    Log "PC lockdown disabled."
}


function Test-UninstallRequested {
    try {
        if (("SG8.LockdownHooks" -as [type]) -and [SG8.LockdownHooks]::ExitRequested) {
            return $true
        }
    } catch {}

    return $false
}

function Remove-RestrictPcStartupAndExit {
    Log "Ctrl+Alt+Q detected. Removing RestrictPC startup task and exiting." "WARN"

    try { Disable-Lockdown } catch {}

    try {
        schtasks.exe /Delete /TN "RestrictPC_Startup" /F | Out-Null
        Log "RestrictPC_Startup task removed."
    } catch {
        Log "Failed to remove RestrictPC_Startup task: $_" "WARN"
    }

    try {
        $installedPath = Join-Path (Join-Path (Get-ProgramDataRoot) "SG8Launcher") "RestrictPC.ps1"
        if ((Test-Path $installedPath) -and (([string]$PSCommandPath).Trim().ToLower() -eq $installedPath.ToLower())) {
            $deleteCmd = "Start-Sleep -Seconds 2; Remove-Item -LiteralPath '$installedPath' -Force -ErrorAction SilentlyContinue"
            Start-Process powershell.exe -WindowStyle Hidden -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command `"$deleteCmd`"" | Out-Null
            Log "RestrictPC.ps1 scheduled for deletion: $installedPath"
        }
    } catch {
        Log "Failed to schedule RestrictPC.ps1 deletion: $_" "WARN"
    }

    try { $script:singleInstanceMutex.ReleaseMutex() } catch {}
    try { $script:singleInstanceMutex.Dispose() } catch {}
    exit 0
}


function Handle-WebSocketMessage {
    param(
        $Message,
        [string]$TerminalId,
        [string]$MachineId,
        [string]$LauncherPath
    )

    $messageType = ([string]$Message.type).Trim()

    if (-not (Is-MessageForThisTerminal -Message $Message -TerminalId $TerminalId -MachineId $MachineId)) {
        return
    }

    if ($messageType -eq "TERMINAL_GAME_LAUNCHED_UPDATE" -or $messageType -eq "TERMINAL_GAME_LAUNCH_UPDATE" -or $messageType -eq "GAME_LAUNCHED_UPDATE") {
        $isLaunchedGame = Get-MessageIsLaunchedGame -Message $Message

        if ($isLaunchedGame -eq $true) {
            Open-Launcher -LauncherPath $LauncherPath
        } else {
            Log "Close command ignored by RestrictPC. Electron handles closing."
        }

        return
    }

    if ($messageType -eq "TERMINAL_LOCK_UPDATE") {
        $isLocked = Get-MessageIsLocked -Message $Message
        Log "Lock command received from websocket: isLocked=$isLocked"

        if ($isLocked -eq $true) {
            Enable-Lockdown
        } elseif ($isLocked -eq $false) {
            Disable-Lockdown
        } else {
            Log "Lock command ignored because isLocked was not a boolean." "WARN"
        }

        return
    }

    if ($messageType -eq "TERMINAL_REMOVED") {
        Disable-Lockdown
        return
    }
}


function Start-Listener {
    param(
        [string]$WsUrl,
        [string]$ApiBaseUrl,
        [string]$TerminalId,
        [string]$MachineId,
        [string]$OutletName,
        [string]$LauncherPath
    )

    Add-Type -AssemblyName System.Net.Http | Out-Null

    while ($true) {
        $ws = $null
        $cts = $null

        try {
            $uri = Build-WebSocketUri -WsUrl $WsUrl -TerminalId $TerminalId -MachineId $MachineId -OutletName $OutletName
            Log "Connecting to websocket: $uri"

            $ws = New-Object System.Net.WebSockets.ClientWebSocket
            $cts = New-Object System.Threading.CancellationTokenSource
            $buffer = New-Object byte[] 16384

            $ws.ConnectAsync($uri, $cts.Token).Wait()
            Log "Websocket connected"

            while ($ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
                if (Test-UninstallRequested) {
                    Remove-RestrictPcStartupAndExit
                }

                if ($script:IsLocked) {
                    Stop-RestrictedProcesses
                }

                $segment = New-Object System.ArraySegment[byte] (, $buffer)
                $receiveTask = $ws.ReceiveAsync($segment, $cts.Token)

                while (-not $receiveTask.Wait(1000)) {
                    if (Test-UninstallRequested) {
                        Remove-RestrictPcStartupAndExit
                    }

                    if ($script:IsLocked) {
                        Stop-RestrictedProcesses
                    }
                }

                $result = $receiveTask.Result

                if ($result.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) {
                    break
                }

                $messageStream = New-Object System.IO.MemoryStream
                if ($result.Count -gt 0) {
                    $messageStream.Write($buffer, 0, $result.Count)
                }

                while (-not $result.EndOfMessage -and $ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
                    $receiveTask = $ws.ReceiveAsync($segment, $cts.Token)
                    while (-not $receiveTask.Wait(1000)) {
                        if (Test-UninstallRequested) {
                            Remove-RestrictPcStartupAndExit
                        }

                        if ($script:IsLocked) {
                            Stop-RestrictedProcesses
                        }
                    }

                    $result = $receiveTask.Result

                    if ($result.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) {
                        break
                    }

                    if ($result.Count -gt 0) {
                        $messageStream.Write($buffer, 0, $result.Count)
                    }
                }

                if ($messageStream.Length -le 0) {
                    $messageStream.Dispose()
                    continue
                }

                $json = [System.Text.Encoding]::UTF8.GetString($messageStream.ToArray())
                $messageStream.Dispose()

                try {
                    $message = $json | ConvertFrom-Json
                    $incomingType = ([string]$message.type).Trim()
                    if (-not [string]::IsNullOrWhiteSpace($incomingType)) {
                        Log "Websocket message received: $incomingType"
                    }
                    Handle-WebSocketMessage -Message $message -TerminalId $TerminalId -MachineId $MachineId -LauncherPath $LauncherPath
                } catch {
                    Log "Websocket message parse failed: $_ | Raw: $json" "WARN"
                }
            }
        } catch {
            Log "Websocket error: $_" "WARN"
        } finally {
            try { if ($ws) { $ws.Dispose() } } catch {}
            try { if ($cts) { $cts.Dispose() } } catch {}
        }

        Log "Websocket disconnected. Reconnecting in 5 seconds. Lock will only apply after websocket messages are received."
        Start-Sleep -Seconds 5
    }
}


Hide-ConsoleWindow

$programDataRoot = Get-ProgramDataRoot
$sg8DataDir = Join-Path $programDataRoot "SG8Launcher"
$identityPath = Join-Path $sg8DataDir "identity.json"
$launcherPath = "C:\Program Files\SG8 Launcher\SG8 Launcher.exe"
$script:LogFilePath = Join-Path $sg8DataDir "RestrictPC.log"
try {
    if (-not (Test-Path $sg8DataDir)) {
        New-Item -Path $sg8DataDir -ItemType Directory -Force | Out-Null
    }
    Add-Content -Path $script:LogFilePath -Value "`r`n===== RestrictPC started $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') =====" -Encoding UTF8
} catch {}

try {
    $identity = Read-JsonFile -Path $identityPath
} catch {
    Log $_ "ERROR"
    exit 1
}

$terminalId = ([string]$identity.terminalId).Trim()
$machineId = ([string]$identity.machineId).Trim()
$outletName = ([string]$identity.outletName).Trim()

if ([string]::IsNullOrWhiteSpace($terminalId)) {
    Log "identity.json is missing terminalId. Run SG8 Launcher Setup again." "ERROR"
    exit 1
}

if ([string]::IsNullOrWhiteSpace($machineId)) {
    Log "identity.json is missing machineId. Run SG8 Launcher Setup again." "ERROR"
    exit 1
}

# RestrictPC uses identity.json only.
# API_BASE_URL and WS_URL must come from identity.json.
# No terminal.config.json and no hardcoded backend fallback.
# If the server is unreachable, this process still runs and reconnects forever.
# Lock commands are applied only from websocket messages.
# Launcher opens immediately on startup as offline fallback, and also opens on websocket isLaunchedGame=true.
$apiValueCandidates = @(
    $identity.API_BASE_URL,
    $identity.apiBaseUrl,
    $identity.backendApiUrl,
    $identity.apiUrl
)

$wsValueCandidates = @(
    $identity.WS_URL,
    $identity.wsUrl,
    $identity.websocketUrl
)

$apiBaseUrlRaw = ""
foreach ($value in $apiValueCandidates) {
    $text = ([string]$value).Trim()
    if (-not [string]::IsNullOrWhiteSpace($text)) {
        $apiBaseUrlRaw = $text
        break
    }
}

$wsUrlRaw = ""
foreach ($value in $wsValueCandidates) {
    $text = ([string]$value).Trim()
    if (-not [string]::IsNullOrWhiteSpace($text)) {
        $wsUrlRaw = $text
        break
    }
}

$apiBaseUrl = Normalize-ApiBaseUrl -Value $apiBaseUrlRaw
$wsUrl = Normalize-WsUrl -Value $wsUrlRaw -ApiBaseUrl $apiBaseUrl

Log "Identity loaded: $identityPath"
Log "API_BASE_URL: $apiBaseUrl"
Log "WS_URL: $wsUrl"
Log "TERMINAL_ID: $terminalId"
Log "MACHINE_ID: $machineId"
Log "OUTLET_NAME: $outletName"
Log "LAUNCHER_PATH: $launcherPath"

# Offline fallback: launch SG8 Launcher immediately when RestrictPC starts.
# This does not update isLaunchedGame. Electron updates isLaunchedGame=true after it opens.
Open-Launcher -LauncherPath $launcherPath

if ([string]::IsNullOrWhiteSpace($wsUrl)) {
    Log "WS_URL is missing in identity.json. RestrictPC will stay running and check identity.json again every 10 seconds." "ERROR"

    while ($true) {
        Start-Sleep -Seconds 10
        try {
            $identity = Read-JsonFile -Path $identityPath
            $wsUrlRaw = ([string]$identity.WS_URL).Trim()
            $apiBaseUrlRaw = ([string]$identity.API_BASE_URL).Trim()
            $apiBaseUrl = Normalize-ApiBaseUrl -Value $apiBaseUrlRaw
            $wsUrl = Normalize-WsUrl -Value $wsUrlRaw -ApiBaseUrl $apiBaseUrl

            if (-not [string]::IsNullOrWhiteSpace($wsUrl)) {
                Log "WS_URL found after retry: $wsUrl"
                break
            }
        } catch {
            Log "Waiting for valid identity.json: $_" "WARN"
        }
    }
}

Start-Listener -WsUrl $wsUrl -ApiBaseUrl $apiBaseUrl -TerminalId $terminalId -MachineId $machineId -OutletName $outletName -LauncherPath $launcherPath
