@echo off
setlocal EnableExtensions

REM ============================================================
REM setup_startup.bat
REM Installs RestrictPC as a hidden Windows logon task.
REM This setup file may show a console while you run it manually.
REM The installed startup task does NOT run this .bat file.
REM The installed startup task runs RestrictPC.ps1 hidden through PowerShell.
REM ============================================================

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] Right-click this file and choose Run as administrator.
    pause
    exit /b 1
)

set SOURCE_PS=%~dp0RestrictPC.ps1
set INSTALL_DIR=%ProgramData%\SG8Launcher
set INSTALL_PS=%INSTALL_DIR%\RestrictPC.ps1
set IDENTITY_FILE=%INSTALL_DIR%\identity.json
set LOG_FILE=%INSTALL_DIR%\RestrictPC.log
set TASK_NAME=RestrictPC_Startup
set REGISTER_PS=%TEMP%\RegisterRestrictPCStartup.ps1
set LAUNCHER_EXE=C:\Program Files\SG8 Launcher\SG8 Launcher.exe

if not exist "%SOURCE_PS%" (
    echo [ERROR] RestrictPC.ps1 not found beside this setup file.
    pause
    exit /b 1
)

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%" >nul 2>&1

if not exist "%IDENTITY_FILE%" (
    echo [ERROR] identity.json not found:
    echo %IDENTITY_FILE%
    echo.
    echo Run SG8 Launcher Setup first and pair this PC to an outlet.
    pause
    exit /b 1
)

REM Stop old listener and remove old visible startup entries.
schtasks /End /TN "%TASK_NAME%" >nul 2>&1
schtasks /Delete /TN "%TASK_NAME%" /F >nul 2>&1
schtasks /Delete /TN "RestrictPC" /F >nul 2>&1
schtasks /Delete /TN "RestrictPC_Launch" /F >nul 2>&1
schtasks /Delete /TN "SG8 RestrictPC" /F >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "RestrictPC" /f >nul 2>&1
reg delete "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" /v "RestrictPC" /f >nul 2>&1
del "%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\RestrictPC*.lnk" /f /q >nul 2>&1
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\RestrictPC*.lnk" /f /q >nul 2>&1
if exist "C:\Program Files\RestrictPC\RestrictPC_Launch.vbs" del "C:\Program Files\RestrictPC\RestrictPC_Launch.vbs" /f /q >nul 2>&1

powershell.exe -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { ($_.Name -match 'powershell') -and ($_.CommandLine -match 'RestrictPC\.ps1') } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch {} }" >nul 2>&1

timeout /t 1 /nobreak >nul
copy /Y "%SOURCE_PS%" "%INSTALL_PS%" >nul
if %errorLevel% neq 0 (
    echo [ERROR] Failed to copy RestrictPC.ps1 to:
    echo %INSTALL_PS%
    pause
    exit /b 1
)

REM Register the startup task through PowerShell so it can be hidden.
> "%REGISTER_PS%" echo $ErrorActionPreference = 'Stop'
>> "%REGISTER_PS%" echo $taskName = '%TASK_NAME%'
>> "%REGISTER_PS%" echo $scriptPath = '%INSTALL_PS%'
>> "%REGISTER_PS%" echo $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
>> "%REGISTER_PS%" echo $powerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
>> "%REGISTER_PS%" echo Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
>> "%REGISTER_PS%" echo $argument = '-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $scriptPath + '"'
>> "%REGISTER_PS%" echo $action = New-ScheduledTaskAction -Execute $powerShellExe -Argument $argument
>> "%REGISTER_PS%" echo $trigger = New-ScheduledTaskTrigger -AtLogOn -User $currentUser
>> "%REGISTER_PS%" echo $principal = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Highest
>> "%REGISTER_PS%" echo $settings = New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Days 1)
>> "%REGISTER_PS%" echo Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force ^| Out-Null

powershell.exe -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "%REGISTER_PS%" >nul 2>&1
if %errorLevel% neq 0 (
    del "%REGISTER_PS%" /f /q >nul 2>&1
    echo [ERROR] Hidden task registration failed.
    echo Make sure this file was run as administrator.
    pause
    exit /b 1
)

del "%REGISTER_PS%" /f /q >nul 2>&1

REM Start RestrictPC now through the hidden scheduled task.
schtasks /Run /TN "%TASK_NAME%" >nul 2>&1

REM Manual setup should also open SG8 Launcher once.
REM No CMS update is sent here. SG8 Launcher updates isLaunchedGame=true after it opens.
if exist "%LAUNCHER_EXE%" (
    start "" "%LAUNCHER_EXE%"
)

endlocal
exit /b 0
