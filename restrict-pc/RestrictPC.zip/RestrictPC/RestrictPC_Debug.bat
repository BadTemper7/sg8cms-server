@echo off
setlocal

set PS_SCRIPT=%~dp0RestrictPC.ps1
set IDENTITY_FILE=%ProgramData%\SG8Launcher\identity.json
set LOG_FILE=%ProgramData%\SG8Launcher\RestrictPC.log
set LAUNCHER_EXE=C:\Program Files\SG8 Launcher\SG8 Launcher.exe

echo ============================================================
echo RestrictPC DEBUG MODE
echo ============================================================
echo.
echo [CHECK] Script:
echo %PS_SCRIPT%
if exist "%PS_SCRIPT%" (echo STATUS: FOUND) else (echo STATUS: NOT FOUND)
echo.
echo [CHECK] Identity:
echo %IDENTITY_FILE%
if exist "%IDENTITY_FILE%" (echo STATUS: FOUND) else (echo STATUS: NOT FOUND)
echo.
echo [CHECK] Launcher:
echo %LAUNCHER_EXE%
if exist "%LAUNCHER_EXE%" (echo STATUS: FOUND) else (echo STATUS: NOT FOUND)
echo.
echo [CHECK] Log:
echo %LOG_FILE%
if exist "%LOG_FILE%" (echo STATUS: FOUND) else (echo STATUS: NOT FOUND YET)
echo.
echo NOTE: RestrictPC uses identity.json only. terminal.config.json is not required.
echo API_BASE_URL and WS_URL are read from identity.json only.
echo Launcher opens only when websocket sends isLaunchedGame=true.
echo RestrictPC opens launcher only from websocket. setup_startup.bat opens launcher once after installing the task.
echo.
echo [INFO] Stopping old hidden RestrictPC instances before debug run...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { ($_.Name -match 'powershell') -and ($_.CommandLine -match 'RestrictPC\.ps1') } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch {} }" >nul 2>&1
timeout /t 1 /nobreak >nul
echo.

if not exist "%PS_SCRIPT%" (
    echo [ERROR] RestrictPC.ps1 is missing.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" -DebugMode

echo.
echo [Script exited]
pause
endlocal
